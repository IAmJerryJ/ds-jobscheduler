Group 23 COMP3100 Project Repository

Authors: Nour Salama, Runde Jia and Chenlin Zhu

The aim of this project is to design and implement a job scheduler for a distributed system.